import { createFileRoute } from "@tanstack/react-router";
import { ClientOnly } from "@tanstack/react-router";
import { lazy, Suspense } from "react";

const HomePage = lazy(() => import("@/components/HomePage.jsx"));

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Muneeb Rehman — Creative Developer & Designer" },
      {
        name: "description",
        content:
          "Portfolio of Muneeb Rehman, creative developer, web & graphic designer and AI enthusiast based in Larkana, Pakistan.",
      },
      { property: "og:title", content: "Muneeb Rehman — Creative Developer & Designer" },
      {
        property: "og:description",
        content:
          "Web development, AI tools and visual design projects by Muneeb Rehman, based in Larkana, Pakistan.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <ClientOnly fallback={<div className="min-h-screen bg-bg" />}>
      <Suspense fallback={<div className="min-h-screen bg-bg" />}>
        <HomePage />
      </Suspense>
    </ClientOnly>
  );
}
