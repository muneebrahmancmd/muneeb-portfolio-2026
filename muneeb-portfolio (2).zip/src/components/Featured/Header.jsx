import { a, useSpring } from "@react-spring/web";
import { Trail } from "./TrailText";
import React, { useEffect, useState } from "react";

const Header = () => {
  const [open, set] = useState();

  useEffect(() => {
    set(true);
  }, []);

  const [horizontal, api] = useSpring(() => ({ from: { transform: 'translateX(0%)' } }));

  // The slide-in only runs on desktop — on phones a 20% shift pushed
  // "Building Real" off the right edge of the screen.
  const horizontalCallback = open => {
    const isDesktop =
      typeof window !== 'undefined' && window.matchMedia('(min-width: 768px)').matches;
    api.start({ transform: `translateX(${open && isDesktop ? '20%' : '0%'})` });
  };
  return (
    <div className="w-full z-10 relative px-4 md:px-0 md:pl-6 font-semibold text-5xl sm:text-6xl md:text-[9rem] text-center md:text-left leading-[0.95] md:leading-none" style={{ letterSpacing: "-0.07em" }}>
      <Trail callback={horizontalCallback}>
        <a.div className="flex justify-center md:justify-start flex-wrap md:flex-nowrap" style={horizontal}>
          <div>Building&nbsp;</div>
          <div>Real&nbsp;</div>
        </a.div>
        <div className="flex justify-center md:justify-start flex-wrap md:flex-nowrap">
          <div>Digital&nbsp;</div>
          <div>Systems&nbsp;</div>
        </div>
      </Trail>
    </div>
  );
};

export default Header;
