import React from 'react'

const SERVICES = [
  {
    title: 'Web Development',
    body:
      'From idea to launch, full cycle development including frontend, backend, and deployment.',
  },
  {
    title: 'AI Tools & Automation',
    body:
      'Building AI powered tools, agents and automations that do real work — from chat agents to full-stack AI products.',
  },
  {
    title: 'Web & UI Design',
    body:
      'Minimal, clean and user focused interfaces with smooth, modern motion.',
  },
  {
    title: 'Graphic Design & Photo Editing',
    body:
      'Posters, thumbnails, brand visuals and high-end photo retouching for digital products.',
  },
]

const SubHeader = () => {
  return (
    <div className='relative md:absolute md:top-1/5 left-0 md:left-1/2 w-full md:-translate-x-1/2 md:mt-40 z-10 flex flex-col md:items-start items-center px-5 md:px-0'>
      <div className='w-full md:w-1/2 text-base md:text-2xl flex flex-col gap-3 md:gap-4 leading-relaxed md:leading-snug text-center md:text-left'>
        <p>
          Muneeb Rehman is a creative developer, web designer, graphic designer, AI enthusiast and photo editor based in Larkana, Pakistan.
        </p>
        <p>
          I build full-stack web apps, AI tools and visual identities — turning ideas into fast, polished products end to end.
        </p>
      </div>

      <div className='about-inline-services w-full md:w-1/2 mt-8 md:mt-12 h-auto md:h-[36vh]'>
        <div className='about-inline-services__head'>
          <span className='about-inline-services__label'>SERVICES</span>
        </div>
        <div className='about-inline-services__grid'>
          {SERVICES.map((service) => (
            <article key={service.title} className='about-inline-services__item'>
              <h4>{service.title}</h4>
              <p>{service.body}</p>
            </article>
          ))}
        </div>
      </div>
    </div>
  )
}

export default SubHeader
