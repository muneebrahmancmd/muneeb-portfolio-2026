
import React from "react";

const Icon = ({ children }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20"
    height="20"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    {children}
  </svg>
);

const InstagramIcon = () => (
  <Icon>
    <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
  </Icon>
);

const TwitterIcon = () => (
  <Icon>
    <path d="M4 4l7.5 9.5L4.5 20" />
    <path d="M20 4l-7.5 9.5L19.5 20" />
  </Icon>
);

const LinkedinIcon = () => (
  <Icon>
    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6z" />
    <rect width="4" height="12" x="2" y="9" />
    <circle cx="4" cy="4" r="2" />
  </Icon>
);

const GithubIcon = () => (
  <Icon>
    <path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.4 5.4 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4" />
    <path d="M9 18c-4.51 2-5-2-7-2" />
  </Icon>
);

const SiteFooter = () => {
  return (
    <footer id="main-footer">
      <div className="footer-top">
        <div className="footer-brand">
          <h1 className="f-logo">MUNEEB</h1>
          <p className="f-desc">
            Muneeb Rehman builds creative web experiences. <br />
            Development, design and AI in one place.
          </p>
          <div className="f-socials">
            <a
              href="https://www.instagram.com/he__muneeb"
              target="_blank"
              rel="noreferrer"
              aria-label="Instagram"
            >
              <InstagramIcon />
            </a>
            <a
              href="https://twitter.com/Muneeb455365487"
              target="_blank"
              rel="noreferrer"
              aria-label="Twitter"
            >
              <TwitterIcon />
            </a>
            <a
              href="https://www.linkedin.com/in/muneeb-soomro-887925333"
              target="_blank"
              rel="noreferrer"
              aria-label="LinkedIn"
            >
              <LinkedinIcon />
            </a>
            <a
              href="https://github.com/muneebrahmancmd"
              target="_blank"
              rel="noreferrer"
              aria-label="GitHub"
            >
              <GithubIcon />
            </a>
          </div>
        </div>
        <div className="footer-links">
          <div className="f-col">
            <h3>EXPLORE</h3>
            <a href="#projects-section">Projects</a>
            <a href="#about">About</a>
            <a href="#contact-section">Get in touch</a>
          </div>
          <div className="f-col">
            <h3>CONTACT</h3>
            <a href="mailto:muneebrahman500@gmail.com">
              muneebrahman500@gmail.com
            </a>
            <a
              href="https://github.com/muneebrahmancmd"
              target="_blank"
              rel="noreferrer"
            >
              GitHub: muneebrahmancmd
            </a>
            <a
              href="https://www.instagram.com/he__muneeb"
              target="_blank"
              rel="noreferrer"
            >
              Instagram: he__muneeb
            </a>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} Muneeb Rehman. All rights reserved.</p>
        <p>Larkana, Pakistan</p>
      </div>
    </footer>
  );
};

export default SiteFooter;
