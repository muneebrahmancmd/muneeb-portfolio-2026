declare module "@/components/HomePage.jsx" {
  const HomePage: () => JSX.Element;
  export default HomePage;
}
